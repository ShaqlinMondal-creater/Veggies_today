<div class="container">
    <div class="image_2"><img src="images/img-3.png" style="width:100px"></div>
    <h1 class="about_taital">About Our Shopping Website <span style="color:orange;">Veggies</span></h1>
    <div class="image_3"><img src="images/bag2.png"></div>
    <p class="">
    Welcome to "Veggies" – your one-stop destination for fresh, organic, and delightful vegetables! At "My Veggies," we believe in bringing nature's goodness right to your doorstep. Our mission is to make healthy living accessible, convenient, and affordable for everyone.
    </p>
    <div class="read_bt_1"><a href="about_us.php">Explore More</a></div>
</div>