<?php
$server="localhost";
$username="root";
$password="";
$database="veggies_today";

$con=mysqli_connect($server,$username,$password,$database);

?>